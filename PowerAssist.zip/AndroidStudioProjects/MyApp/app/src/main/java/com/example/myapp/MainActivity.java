package com.example.test3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapp.R;

public class MainActivity extends AppCompatActivity {
    Button b;
    TextView t1;
    TextView t2;
    TextView t3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=(Button) findViewById(R.id.button3);
        t1=(TextView) findViewById(R.id.n1);
        t2=(TextView) findViewById(R.id.n2);
        t3=(TextView) findViewById(R.id.no3);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a=Integer.parseInt(t1.getText().toString());
                int b=Integer.parseInt(t2.getText().toString());
                int add=a+b;
                t3.setText("Answer: " +add);
            }
        });
    }
}

