package com.example.powerassist;

public class ChargingStation {
    private String name;
    private String location;
    private String capacity;
    private String price;

    public ChargingStation(String name, String location, String capacity, String price) {
        this.name = name;
        this.location = location;
        this.capacity = capacity;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getCapacity() {
        return capacity;
    }

    public String getPrice() {
        return price;
    }
}

