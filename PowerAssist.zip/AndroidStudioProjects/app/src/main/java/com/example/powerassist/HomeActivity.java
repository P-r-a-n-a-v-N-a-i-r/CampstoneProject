package com.example.powerassist;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Find views by their IDs
        Button profileButton = findViewById(R.id.buttonProfile);
        Button mapButton = findViewById(R.id.buttonMap);
        Button priceCalculatorButton = findViewById(R.id.buttonPriceCalculator);
        Button stationsButton = findViewById(R.id.buttonStations);

        // Set click listeners for the buttons
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the ProfileActivity
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });

        mapButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the MapActivity
//                Intent intent = new Intent(HomeActivity.this, MapActivity.class);
//                startActivity(intent);
                double latitude = 37.7749; // Replace with the desired latitude
                double longitude = -122.4194; // Replace with the desired longitude

                Intent intent = new Intent(HomeActivity.this, MapActivity.class);
                intent.putExtra("latitude", latitude);
                intent.putExtra("longitude", longitude);
                startActivity(intent);
            }
        });

        priceCalculatorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the PriceCalculatorActivity
                Intent intent = new Intent(HomeActivity.this, PriceCalculatorActivity.class);
                startActivity(intent);
            }
        });

        stationsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start the StationsActivity
                Intent intent = new Intent(HomeActivity.this, StationsActivity.class);
                startActivity(intent);
            }
        });
    }
}