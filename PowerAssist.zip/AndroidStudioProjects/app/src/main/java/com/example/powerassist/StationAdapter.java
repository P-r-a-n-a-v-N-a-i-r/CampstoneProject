package com.example.powerassist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class StationAdapter extends RecyclerView.Adapter<StationAdapter.ViewHolder> {

    private List<ChargingStation> chargingStations;

    public StationAdapter(List<ChargingStation> chargingStations) {
        this.chargingStations = chargingStations;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.station_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChargingStation station = chargingStations.get(position);
        holder.textViewName.setText(station.getName());
        holder.textViewLocation.setText(station.getLocation());
        holder.textViewCapacity.setText(station.getCapacity());
        holder.textViewPrice.setText(station.getPrice());
    }

    @Override
    public int getItemCount() {
        return chargingStations.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName;
        TextView textViewLocation;
        TextView textViewCapacity;
        TextView textViewPrice;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewLocation = itemView.findViewById(R.id.textViewLocation);
            textViewCapacity = itemView.findViewById(R.id.textViewCapacity);
            textViewPrice = itemView.findViewById(R.id.textViewPrice);
        }
    }
}

