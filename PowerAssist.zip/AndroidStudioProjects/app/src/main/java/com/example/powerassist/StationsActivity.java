package com.example.powerassist;

// StationsActivity.java
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class StationsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private StationAdapter stationAdapter;
    private List<ChargingStation> chargingStations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stations);

        // Create a list of charging stations (replace this with actual data)
        chargingStations = new ArrayList<>();
        chargingStations.add(new ChargingStation("Station 1", "Location 1", "10 kW", "Rs 5/kWh"));
        chargingStations.add(new ChargingStation("Station 2", "Location 2", "20 kW", "Rs 6/kWh"));
        // Add more stations as needed

        // Initialize the RecyclerView and its adapter
        recyclerView = findViewById(R.id.recyclerViewStations);
        stationAdapter = new StationAdapter(chargingStations);

        // Set the RecyclerView's layout manager and adapter
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(stationAdapter);
    }
}
