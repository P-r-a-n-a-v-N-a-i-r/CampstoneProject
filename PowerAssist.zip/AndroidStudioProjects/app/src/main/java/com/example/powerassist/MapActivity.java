package com.example.powerassist;

import androidx.fragment.app.FragmentActivity;
import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.powerassist.databinding.ActivityMapBinding;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add markers for 5 dummy locations
        addMarkerToMap(new LatLng(37.7749, -122.4194), "Location 1", "Description for Location 1");
        addMarkerToMap(new LatLng(34.0522, -118.2437), "Location 2", "Description for Location 2");
        addMarkerToMap(new LatLng(40.7128, -74.0060), "Location 3", "Description for Location 3");
        addMarkerToMap(new LatLng(51.5074, -0.1278), "Location 4", "Description for Location 4");
        addMarkerToMap(new LatLng(48.8566, 2.3522), "Location 5", "Description for Location 5");
    }

    private void addMarkerToMap(LatLng position, String title, String snippet) {
        mMap.addMarker(new MarkerOptions()
                .position(position)
                .title(title)
                .snippet(snippet));

        // Move camera to the first marker position
        if (mMap.getCameraPosition().target == null) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 10f));
        }
    }
}
