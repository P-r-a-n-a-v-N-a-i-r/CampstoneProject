package com.example.powerassist;

// PriceCalculatorActivity.java
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PriceCalculatorActivity extends AppCompatActivity {

    private EditText batteryCapacityEditText;
    private EditText electricityPriceEditText;
    private TextView totalCostTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_price_calculator);

        batteryCapacityEditText = findViewById(R.id.editTextBatteryCapacity);
        electricityPriceEditText = findViewById(R.id.editTextElectricityPrice);
        totalCostTextView = findViewById(R.id.textViewTotalCost);

        // Set text change listeners on EditText fields to calculate the total cost
        batteryCapacityEditText.addTextChangedListener(priceCalculatorTextWatcher);
        electricityPriceEditText.addTextChangedListener(priceCalculatorTextWatcher);
    }

    private TextWatcher priceCalculatorTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            calculateTotalCost();
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    private void calculateTotalCost() {
        String batteryCapacityStr = batteryCapacityEditText.getText().toString().trim();
        String electricityPriceStr = electricityPriceEditText.getText().toString().trim();

        if (batteryCapacityStr.isEmpty() || electricityPriceStr.isEmpty()) {
            totalCostTextView.setText("Total Cost: N/A");
            return;
        }

        double batteryCapacity = Double.parseDouble(batteryCapacityStr);
        double electricityPrice = Double.parseDouble(electricityPriceStr);

        // Calculate the total cost
        double totalCost = batteryCapacity * electricityPrice;

        totalCostTextView.setText(String.format("Total Cost: Rs %.2f", totalCost));
    }
}
