package com.example.powerassist;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class UserDataSource {
    private SQLiteDatabase database;
    private UserDBHelper dbHelper;

    public UserDataSource(Context context) {
        dbHelper = new UserDBHelper(context);
    }

    public void open() {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long createUser(String username, String phone, String email, String password) {
        ContentValues values = new ContentValues();
        values.put(UserDBHelper.COLUMN_USERNAME, username);
        values.put(UserDBHelper.COLUMN_PHONE, phone);
        values.put(UserDBHelper.COLUMN_EMAIL, email);
        values.put(UserDBHelper.COLUMN_PASSWORD, password);
        return database.insert(UserDBHelper.TABLE_USERS, null, values);
    }

    public boolean isUserValid(String email, String password) {
        String[] columns = {UserDBHelper.COLUMN_ID};
        String selection = UserDBHelper.COLUMN_EMAIL + " = ? AND " + UserDBHelper.COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {email, password};
        Cursor cursor = database.query(UserDBHelper.TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    @SuppressLint("Range")
    public User getUserByEmail(String email) {
        User user = null;
        String[] columns = {UserDBHelper.COLUMN_USERNAME, UserDBHelper.COLUMN_PHONE, UserDBHelper.COLUMN_EMAIL};
        String selection = UserDBHelper.COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};
        Cursor cursor = database.query(UserDBHelper.TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String username = cursor.getString(cursor.getColumnIndex(UserDBHelper.COLUMN_USERNAME));
            String phone = cursor.getString(cursor.getColumnIndex(UserDBHelper.COLUMN_PHONE));
            String userEmail = cursor.getString(cursor.getColumnIndex(UserDBHelper.COLUMN_EMAIL));
            user = new User(    username, phone, userEmail);
            cursor.close();
        }

        return user;
    }
}


