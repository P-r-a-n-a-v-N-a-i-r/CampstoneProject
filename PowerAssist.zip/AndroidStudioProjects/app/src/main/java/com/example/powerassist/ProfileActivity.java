package com.example.powerassist;

// ProfileActivity.java
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        String userEmail = "admin@gmail.com";


        // Retrieve user profile data from the SQLite database
        UserDataSource userDataSource = new UserDataSource(this);
        userDataSource.open();

        User user = userDataSource.getUserByEmail(userEmail);

        userDataSource.close();

        // Update the UI with user profile data
        if (user != null) {
            TextView usernameTextView = findViewById(R.id.textViewUsername);
            TextView phoneTextView = findViewById(R.id.textViewPhone);
            TextView emailTextView = findViewById(R.id.textViewEmail);

            usernameTextView.setText(user.getUsername());
            phoneTextView.setText(user.getPhone());
            emailTextView.setText(user.getEmail());
        }
    }
}
